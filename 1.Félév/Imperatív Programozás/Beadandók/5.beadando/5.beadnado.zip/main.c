#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "rle.h"

int main(void)
{
  const int maxertek=255;
  char szoveg [maxertek];
  scanf("%s",szoveg);
  int j=0;
  while(szoveg[j]!='\0')
  {
    if (strchr("���qwertzuiop��asdfghjkl����yxcvbnm",szoveg[j])==NULL)
    {
      printf("Hib�s bemenet!\n");
      return 1;
    }
    ++j;
  }
  Encoded* kodolt;
  kodolt=encode(szoveg);
  char* dekodolt =(char *) malloc (2*kodolt->length*sizeof(char));
  dekodolt = decode(kodolt);
  for (int i=0;i<(kodolt->length)*2;++i)
  {
    if(i%2==0)
    {
   printf("%d",dekodolt[i]);
    }
    else
    {
   printf("%c",dekodolt[i]);
    }
  }
  printf("\n");
  printf(" -> %s",szoveg);
  free (dekodolt);
  free(kodolt);
  return 0;
}
