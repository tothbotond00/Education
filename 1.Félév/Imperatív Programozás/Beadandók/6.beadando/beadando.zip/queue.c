#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "queue.h"

//Node def
struct Node
{
  int value;
  struct Node* next;
};

//M�d�s�t� m�veletek

void initialize (Queue* list)
{
  list->back = NULL;
  list->front = NULL;
}

void enqueue (Queue* list,int node)
{
  if (isEmpty(list))
  {
    Node* elem = (Node*) malloc(sizeof(Node));
    elem->value = node;
    elem->next = NULL;
    list->front = elem;
    list->back = elem;
  }
  else
  {
    Node* elem = (Node*) malloc(sizeof(Node));
    elem->value = node;
    elem->next = NULL;
    list->back->next = elem;
    list->back =elem;
  }
}

void dequeue (Queue* list)
{
  if (list->front->next==NULL)
  {
    free(list->front);
    list-> front=NULL;
    list-> back=NULL;
  }
  else
  {
  Node* elem =list->front->next;
  free (list->front);
  list->front =NULL;
  list->front =elem;
  }
}

void empty (Queue* list)
{
  while (!(isEmpty(list)))
  {
    dequeue(list);
  }
}

//Nem m�dos�t� m�veletek

bool isEmpty (Queue* list)
{
  if (list->front==NULL) return true;
  else return false;
}

int front (Queue* list)
{
  if (isEmpty(list)) return -1;
  else return list->front->value;
}

int back (Queue* list)
{
  if (isEmpty(list)) return -1;
  else return list->back->value;
}

int length (Queue* list)
{
  int db=0;
  Node* elem =list->front;
  while (elem !=NULL)
  {
    ++db;
    elem = elem->next;
  }
  return db;
}

void display (Queue* list)
{
  if (isEmpty(list))
  {
    printf("The queue is empty\n");
  }
  else
  {
  Node* elem =list->front;
  while (elem !=NULL)
  {
    printf("%d -> ",elem->value);
    elem = elem->next;
  }
  printf("nil\n");
  }
}
