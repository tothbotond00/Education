package horsegame;

public class HorseGame {

    public static void main(String[] args) {
        HorseGameGUI gui = new HorseGameGUI();
    }
}
