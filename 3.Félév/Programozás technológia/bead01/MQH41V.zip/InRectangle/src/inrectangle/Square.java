/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inrectangle;

/**
 *
 * @author Botond
 */
public class Square extends Shape {
    
    public Square(double x, double y, double side)throws NegativeSideException {
        super(x,y,side);
        rec = side*side;
    }
    
    public Square(Shape e){
        super(e);
        rec = side*side;
    }
    
     /**
     * Calculates the inbounding rectangles area of the square.
     * T = a * a
     * @return the area of the inbounding rectangle
     */
    @Override
    public double getInRectangleArea(){
        return rec;
    }
    
    @Override
    public String getType(){
        return "s";
    }
    
}