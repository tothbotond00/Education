package snakegame;

class SnakeGame {
    /**
     * Starts up the StartGUI.
     * @param args 
     */
    public static void main(String[] args) {
        StartGUI gui = new StartGUI();
    }

}
