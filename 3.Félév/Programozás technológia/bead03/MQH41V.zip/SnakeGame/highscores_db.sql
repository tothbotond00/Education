create database Highscores;
create table Highscores.highscores (
timestamp timestamp,
name varchar(255),
score int
);