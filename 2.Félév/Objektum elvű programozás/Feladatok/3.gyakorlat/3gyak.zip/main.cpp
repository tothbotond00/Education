#include <iostream>
#include "menu.h"

int main()
{
    std::cout<<"Prioritasos sor"<<std::endl;

    Menu menu;
    menu.run();

    return 0;
}
