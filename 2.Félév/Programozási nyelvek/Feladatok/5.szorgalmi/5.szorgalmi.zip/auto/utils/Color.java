package auto.utils;

public enum Color {
RED,GREEN,BLUE;
Color() {};
}