class AlreadyContainedException extends Exception {
  public AlreadyContainedException(String message){
    super(message);
  }
}