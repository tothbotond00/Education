class Main {
  public static void main(String[] args) {
    System.out.println(TelevisionShop.SAMSUNG);
    System.out.println("Min diameter :"+TelevisionShop.getMin());
    System.out.println("Max diameter :"+TelevisionShop.getMax());
    TelevisionShop.getStock();
  }
}