public class Logger {
  void log (String str){
    
  }
}